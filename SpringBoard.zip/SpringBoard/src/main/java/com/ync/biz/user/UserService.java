package com.ync.biz.user;

public interface UserService {

	public UserVO getUser(UserVO vo);
	
	void insertUser(UserVO vo);

}